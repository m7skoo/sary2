upgrade flutter sdk to 2.10.0 to run the project with out issues. 
